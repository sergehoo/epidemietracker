@@include('@@nodeRoot/node_modules/jquery/dist/jquery.min.js')
@@include('@@nodeRoot/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js')
@@include('vendors/nioapp/nioapp.min.js') 

@@include('@@nodeRoot/node_modules/simplebar/dist/simplebar.min.js') 
@@include('@@nodeRoot/node_modules/select2/dist/js/select2.full.min.js')

@@include('@@nodeRoot/node_modules/chart.js/dist/Chart.min.js')

/** DataTable */
@@include('@@nodeRoot/node_modules/datatables.net/js/jquery.dataTables.min.js')
@@include('@@nodeRoot/node_modules/datatables.net-responsive/js/dataTables.responsive.min.js')
@@include('@@nodeRoot/node_modules/datatables.net-bs4/js/dataTables.bootstrap4.min.js')
@@include('@@nodeRoot/node_modules/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')

/** Date and Time Picker */
@@include('@@nodeRoot/node_modules/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')
@@include('@@nodeRoot/node_modules/jquery-timepicker/jquery.timepicker.js')

/** Code Prettify */
@@include('vendors/prettify.js')